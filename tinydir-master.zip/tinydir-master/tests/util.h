#pragma once

void make_temp_file(const char *prefix, char *out);
